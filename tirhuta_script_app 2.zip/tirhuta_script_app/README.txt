Videha eLearning Quiz — Tirhuta Script — Origin & Development
=====================================================
तिरहुता लिपिक उद्भव ओ विकास  (1000 प्रश्न / questions)

© Gajendra Thakur, Editor — Videha eJournal
VIDEHA ISSN 2229-547X · First Maithili Fortnightly eJournal · Since 2000
https://www.videha.co.in · https://www.videha.co.in/videha-elearning.htm
[Beta Version; suggestions invited]

HOW TO RUN (fully offline — no installation, no internet)
  Windows : double-click  VidehaQuiz-Windows.exe
  macOS   : double-click  VidehaQuiz-macOS.app   (first time: right-click → Open)
  Linux   : run  ./VidehaQuiz-Linux.sh
  Any OS  : simply open  quiz.html  in any browser

The quiz opens in your default browser. Click an option for instant
green/red feedback with the explanation. Use the खण्ड (chapter) list to
navigate; "सभ खण्ड देखू ▾" expands the full chapter list.

Keep all files of this folder together.
