#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xdg-open "$DIR/quiz.html" 2>/dev/null || sensible-browser "$DIR/quiz.html"
