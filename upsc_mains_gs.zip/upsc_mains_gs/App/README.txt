UPSC Civil Services Mains — GS Papers I-IV (2013-2025)
Descriptive Question Bank with Model Answers (965 questions)

(c) Gajendra Thakur, Editor - Videha eJournal | ISSN 2229-547X | www.videha.co.in
[Beta Version; suggestions invited]

Windows: double-click VidehaQuiz-Windows.exe | macOS: VidehaQuiz-macOS.app (right-click > Open first time)
Linux: ./VidehaQuiz-Linux.sh | Any OS: open quiz.html in a browser. Fully offline.
Click "Show Model Answer" under any question to reveal the model answer.
