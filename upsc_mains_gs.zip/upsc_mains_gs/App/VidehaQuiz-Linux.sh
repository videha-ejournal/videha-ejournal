#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xdg-open "$DIR/quiz.html"
